import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

//Transformation Made.
public class TestXss_151_PageAtt extends FatherClass{
	
	
	
	@Before
	public void prepare(){
		FatherClass("professor","professor");
	}
	
	@Test
	public void test(){
		tester.clickLinkWithExactText("Steganography");
		tester.assertMatch("Class Settings");
		tester.clickLinkWithExactText("Announcements");
		tester.assertMatch("View Announcements");
		tester.setWorkingForm("announcements");
		tester.setHiddenField("page", "4'> <a href=www.unitn.it>malicious link</a><'br");
		//tester.clickLinkWithExactText("Announcements");
		addSubmitButton("html//form[@name='announcements']");
		tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");
		
	}
}