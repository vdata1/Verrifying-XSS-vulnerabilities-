import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_38_SelectClassAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("professor", "professor");
	}
	
	@Test
	public void test(){ 
		tester.clickLinkWithText("Steganography");
		
		tester.assertMatch("Class Settings");
		tester.clickLinkWithText("Assignments");
		
		tester.assertMatch("Manage Assignments");
		tester.setWorkingForm("assignments");
		tester.clickElementByXPath("html//input[@value='13']");
		
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Assignment");
		
		tester.setWorkingForm("editassignment");
		tester.setTextField("selectclass", "2'> <a href=\"unitn.it\">malicious link</a>'");
		tester.clickButtonWithText("Edit Assignment");
		tester.assertLinkNotPresentWithText("malicious link");
		
	}
	
}
