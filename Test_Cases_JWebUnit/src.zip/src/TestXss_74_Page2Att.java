import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_74_Page2Att extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test", "test");
	}

	@Test
	public void myTest(){
		
		tester.clickLinkWithText("Semesters");
		
		tester.assertMatch("Manage Semesters");
		tester.setWorkingForm("semesters");
		
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New Semester");
		tester.setWorkingForm("addsemester");
		tester.setTextField("page2", "5'> <a href=\"unitn.it\">malicious link</a><br '");
		addSubmitButton("html//form[@name='addsemester']");
		tester.submit();
		//tester.clickButtonWithText("Add Semester");		
		tester.assertLinkNotPresentWithText("malicious link");	
	}
}
