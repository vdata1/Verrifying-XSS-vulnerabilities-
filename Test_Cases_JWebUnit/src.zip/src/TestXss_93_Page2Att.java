import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_93_Page2Att extends FatherClass {
		
		
		@Before	
		public void prepare() {
			FatherClass("parent", "parent");
		}
		@Test
		public void test() {
			
			tester.setWorkingForm("classes"); 
			tester.setTextField("page2", "5'> <a  href=\"unitn.it\">malicious link</a>");
			//tester.clickLinkWithExactText("AbdulRahman Hamdan"); //with this, its FP cuz it's filtered.
			addSubmitButton("html//form[@name='classes']");
			tester.submit();
			tester.assertLinkNotPresentWithText("malicious link");
		}
	}


