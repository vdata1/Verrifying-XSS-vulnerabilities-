import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

public class TestXss_19_Page2Att extends FatherClass{
	
	@Before	
	public void prepare() {
		FatherClass("test","test");
	}
	@Test
	public void test() {
		tester.clickLinkWithExactText("Terms");
		tester.assertMatch("Manage Terms");
		
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New Term");
		
		tester.setWorkingForm("addterm");
		tester.setHiddenField("page2", "6'><a  href=\"unitn.it\">malicious link</a><'");
		
		addSubmitButton("html//form[@name='addterm']");
		tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");

	}
}
