

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_233_Page2Att extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test","test");
		
	}

	@Test
	public void test(){
		tester.clickLinkWithExactText("Classes");
		tester.assertMatch("Manage Classes");
		tester.setWorkingForm("classes");
		addSubmitButton("html//form[@name='classes']");
		tester.setHiddenField("page2","25'> <a href=www.unitn.it>malicious link</a> <br'");
		tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");
	}
}


