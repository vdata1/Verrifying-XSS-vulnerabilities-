import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_291_Page2Att extends FatherClass {

	@Before
	public void prepare(){
		FatherClass("test","test");
	}
	
	@Test
	public void test(){
	
		
		tester.clickLinkWithExactText("Parents");
		tester.assertMatch("Manage Parents");
		
		tester.setWorkingForm("parents");
		
		tester.setHiddenField("page2", "'> <a href=www.unitn.it>malicious link</a> <br '");
		
		addSubmitButton("html//form[@name='parents']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
	
	
}
