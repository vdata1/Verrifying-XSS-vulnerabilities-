

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_203_PageAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("parent","parent");
		
	}

	@Test
	public void test(){
		tester.clickLinkWithExactText("AbdulRahman Hamdan");
		tester.assertMatch("AbdulRahman Hamdan's Classes");
		tester.clickLinkWithExactText("Steganography");
		tester.assertMatch("Class Settings");
		tester.clickLinkWithExactText("Grades");
		tester.assertMatch("View Grades");
	
		tester.setWorkingForm("grades");
		tester.setHiddenField("page", "'> <a href=www.unitn.it>malicious link</a> <br '");
		addSubmitButton("html//form[@name='grades']");
		tester.submit(); 
		//tester.clickLinkWithExactText("Classes");
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
}

