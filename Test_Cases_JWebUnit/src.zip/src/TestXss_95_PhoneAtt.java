import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
	
public class TestXss_95_PhoneAtt extends FatherClass{
					
		@Before
		public void prepare(){
				FatherClass("test","test");
			}
			
		@Test
		public void test(){
			tester.clickLinkWithExactText("Log Out");
			FatherClass("test","test");
			tester.clickLinkWithText("School");


			tester.assertMatch("Manage School Information");
			previousValue = tester.getElementByXPath("html//input[@name='schoolphone']").getTextContent();
			tester.setTextField("schoolphone","<br name=X>");
			tester.clickButtonWithText(" Update ");
			
			tester.clickLinkWithText("Log Out");
			
			tester.assertMatch("Today's Message");
			tester.assertLinkNotPresentWithText("malicious link");			}
			
		@After
		public void cleanUp(){
				if  (previousValue!=null){
					
					FatherClass("test","test");
					tester.assertMatch("Manage Classes");
					tester.clickLinkWithText("School");
					
					tester.assertMatch("Manage School Information");
					tester.setWorkingForm("info");
					tester.setTextField("schoolphone", previousValue);
					tester.clickButtonWithText(" Update ");
					
					tester.clickLinkWithText("Log Out");
			}
		}
}



