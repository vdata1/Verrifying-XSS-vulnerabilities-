import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_263_PageAtt extends FatherClass {

	@Before
	public void prepare(){
		FatherClass("test","test");
	}
	
	@Test
	public void test(){
	
		
		tester.clickLinkWithExactText("Terms");
		tester.assertMatch("Manage Terms");
		
		tester.setWorkingForm("terms");
		
		tester.setHiddenField("page", "'> <a href=www.unitn.it>malicious link</a> <br '");
		
		addSubmitButton("html//form[@name='terms']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
	
	
}
