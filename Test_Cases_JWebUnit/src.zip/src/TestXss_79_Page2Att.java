import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_79_Page2Att extends FatherClass {
		
		
		@Before	
		public void prepare() {
			FatherClass("professor", "professor");
		}
		@Test
		public void test() {
			
			tester.clickLinkWithText("Steganography");
			tester.assertMatch("Class Settings");
			tester.clickLinkWithText("Grades");
			tester.assertMatch("Grades");
			tester.clickElementByXPath("html//select[@name='assignment']//option[1]");
			tester.setWorkingForm("grades");
			tester.checkCheckbox("delete[]","1");
			tester.clickButtonWithText("Edit");
			tester.assertMatch("Edit Grade");
			tester.setWorkingForm("editgrade");
			previousValue = tester.getElementByXPath("html//input[@name='assignment']").getTextContent();
			tester.setHiddenField("page2","2'><a  href=\"unitn.it\">malicious link</a><br '");
			addSubmitButton("html//form[@name='editgrade']");
			tester.submit();
			tester.assertLinkNotPresentWithText("malicious link");
		}
	}


