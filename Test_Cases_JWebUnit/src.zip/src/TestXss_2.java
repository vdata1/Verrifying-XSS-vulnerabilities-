import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_2 extends FatherClass{
	
	
	
	@Before
	public void prepare(){
		FatherClass("test","test");
		
	}
	
	@Test
	public void Test(){
		
		tester.clickLinkWithExactText("School");
		tester.assertMatch("Manage School Information");
		previousValue = "VSchool"; //tester.getElementByXPath("html//input[@name='schoolname']").getTextContent();
		tester.setWorkingForm("info");
		tester.setTextField("schoolname","<a href=www.unitn.it>XSS</a>"); //good, less than 40 characters :D 
		
		tester.clickButtonWithText(" Update ");
		
		tester.assertLinkNotPresentWithText("XSS");
	}
	
	@After
	public void CleanUp(){
		FatherClass("test","test");
		tester.clickLinkWithExactText("School");
		tester.assertMatch("Manage School Information");
		tester.setWorkingForm("info");
		tester.setTextField("schoolname",previousValue);
		tester.clickButtonWithText(" Update ");
		//System.out.println(previousValue + " XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
	}
	
}