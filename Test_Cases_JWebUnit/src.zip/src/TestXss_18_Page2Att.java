import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

public class TestXss_18_Page2Att extends FatherClass{
	
	@Before	
	public void prepare() {
		FatherClass("test","test");
	}
	@Test
	public void test() {
		tester.clickLinkWithExactText("Users");
		tester.assertMatch("Manage Users");
		
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New User");
		
		tester.setWorkingForm("adduser");
		tester.setHiddenField("page2", "14'><a  href=\"unitn.it\">malicious link</a><'");
		//tester.clickButtonWithText("Add User");
		addSubmitButton("html//form[@name='adduser']");
		tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");

	}
}
