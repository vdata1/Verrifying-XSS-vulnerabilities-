

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_237 extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test","test");
		
	}

	@Test
	public void test(){
		tester.clickLinkWithExactText("Terms");
		tester.assertMatch("Manage Terms");
		tester.setWorkingForm("terms");
		tester.checkCheckbox("delete[]","1");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Term");
		tester.setWorkingForm("editterm");
		previousValue = tester.getElementTextByXPath("html//input[@name='title']");
		tester.setTextField("title", "<a href=c>S</a>");
		tester.clickButtonWithText("Edit Term");
		////here, it's obvious vulnerable!
		tester.clickLinkWithExactText("Semesters");
		tester.assertLinkNotPresentWithText("S");
	}
	@After
	public void cleanUp(){
		//tester.clickLinkWithExactText("Terms");
		
		tester.clickLinkWithExactText("Terms");
		tester.assertMatch("Manage Terms");
		tester.setWorkingForm("terms");
		tester.checkCheckbox("delete[]","1");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Term");
		tester.setWorkingForm("editterm");
		//previousValue = tester.getElementTextByXPath("html//input[@name='title']");
		tester.setTextField("title", previousValue);
		tester.clickButtonWithText("Edit Term");
		
	}
}


