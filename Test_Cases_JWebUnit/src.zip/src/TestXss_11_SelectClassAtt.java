import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;


//Transformation made 
public class TestXss_11_SelectClassAtt extends FatherClass {
	@Before
	public void prepare(){
		FatherClass("professor", "professor");
	}

	@Test
	public void myTest(){
		
		tester.clickLinkWithText("Steganography");
		
		tester.assertMatch("Class Settings");
		tester.clickLinkWithText("Assignments");
		
		tester.assertMatch("Manage Assignments");
		tester.setWorkingForm("assignments");
		tester.setTextField("selectclass", "4 '> <a href=\"unitn.it\">malicious link</a><br '");
		//tester.clickButtonWithText("Add");
		addSubmitButton("//form[@name='assignments']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
		
	}

	

}






///





