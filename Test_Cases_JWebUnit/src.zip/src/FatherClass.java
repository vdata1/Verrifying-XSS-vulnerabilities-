import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class FatherClass {
	WebTester tester; 
    String previousValue = null;
    
	public void FatherClass(){
		tester = new WebTester();
		tester.setBaseUrl("http://192.168.56.101/schoolmate");
	}
	
	public void FatherClass(String uname, String passwd) {
		tester = new WebTester();
		tester.setBaseUrl("http://192.168.56.101/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", uname);	
		tester.setTextField("password", passwd);	
		tester.submit();
		if(uname == "professor"){
			tester.assertMatch("Abdullah ALHamdan's Classes");
		}
		else if(uname == "test"){
			tester.assertMatch("Manage Classes");
		}
		else if(uname == "student"){
			tester.assertMatch("AbdulRahman Hamdan's Classes");
		}
		else if(uname=="parent"){
			tester.assertMatch("Students of Mohammad ALHamdan");
		}
		else {
			System.out.println("Something not good!");
		}
	}
	public void addSubmitButton(String fromXpath) {
			IElement element = tester.getElementByXPath(fromXpath);
			DomElement form = ((HtmlUnitElementImpl)element).getHtmlElement();
			InputElementFactory factory = InputElementFactory.instance;
			AttributesImpl attributes = new AttributesImpl();
			attributes.addAttribute("", "", "type", "", "submit");
			HtmlElement submit = factory.createElement(form.getPage(), "input", attributes);
			form.appendChild(submit);
	}	  
	public void addButton(String fromXpath){
		IElement element = tester.getElementByXPath(fromXpath);
		DomElement form = ((HtmlUnitElementImpl)element).getHtmlElement();
		InputElementFactory factory = InputElementFactory.instance;
		AttributesImpl attributes = new AttributesImpl();
		//attributes.addAttribute("", "", "type", "", "document.assignments.deleteassignment.value=1;");
		attributes.addAttribute("", "", "type", "", "document.assignments.deleteassignment.value=1;");
		HtmlElement submit = factory.createElement(form.getPage(), "input", attributes);
		form.appendChild(submit);
	} 
}
		

