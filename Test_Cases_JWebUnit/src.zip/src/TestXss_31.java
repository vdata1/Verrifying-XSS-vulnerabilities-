import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_31 extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test", "test");
	}

	@Test
	public void myTest(){
		
		
		tester.clickLinkWithExactText("Classes");
		tester.assertMatch("Manage Classes");
		tester.setWorkingForm("classes");
		tester.checkCheckbox("delete[]","1");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Class");
		tester.setWorkingForm("editclass");
		previousValue = tester.getElementTextByXPath("html//input[@name='title']");
		tester.setTextField("title", "X<a href=a>*</a>");
		tester.clickButtonWithText("Edit Class");
		//here, it's obvious vulnerable!
		//I edited an already existed course with an assignment. 
		tester.clickLinkWithExactText("Log Out");
		
		
		//Login as a student to View the Assignment to make sure it will present on the page. 
		FatherClass("student", "student");
		
		tester.clickLinkWithText("X");
		tester.assertMatch("Class Settings");
		
		tester.clickLinkWithText("Assignments");
		tester.assertMatch("View Assignments");
		tester.assertLinkNotPresentWithText("*");
		
		tester.clickLinkWithExactText("Log Out");
	}
	@After
	public void cleanUp(){
		
		FatherClass("test","test");
		tester.clickLinkWithExactText("Classes");
		tester.assertMatch("Manage Classes");
		tester.setWorkingForm("classes");
		tester.checkCheckbox("delete[]","1");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Class");
		tester.setWorkingForm("editclass");
		tester.setTextField("title", previousValue);
		tester.clickButtonWithText("Edit Class");
		
	}
}
