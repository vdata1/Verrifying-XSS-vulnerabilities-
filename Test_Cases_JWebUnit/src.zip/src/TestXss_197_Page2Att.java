

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_197_Page2Att extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("parent","parent");
		
	}

	@Test
	public void test(){
		
		tester.setWorkingForm("student");
		tester.setHiddenField("page2", "'> <a href=www.unitn.it>malicious link</a> <br '");
		addSubmitButton("html//form[@name='student']");
		tester.submit(); 
		//tester.clickLinkWithExactText("Classes");
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
}

