import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
	
public class TestXss_95_SchoolNameAtt extends FatherClass{
					
		@Before
		public void prepare(){
				FatherClass("test","test");
			}
			
		@Test
		public void test(){
			
				tester.clickLinkWithText("School");	
				tester.assertMatch("Manage School Information");
				tester.setWorkingForm("info");
				previousValue = "VSchool";//tester.getElementByXPath("html//input[@name='schoolname']").getTextContent();
				tester.setTextField("schoolname","<a  href=\"unitn.it\">malicious link</a>");
				//addSubmitButton("html//form[@name='info']");
				//tester.submit();
				
				tester.clickButtonWithText(" Update ");
				tester.clickLinkWithText("Log Out");
				tester.assertMatch("Today's Message");
				tester.assertLinkNotPresentWithText("malicious link");
			}
			
		@After
		public void cleanUp(){
				if  (previousValue!=null){
					
					FatherClass("test","test");
					tester.assertMatch("Manage Classes");
					tester.clickLinkWithText("School");
					
					tester.assertMatch("Manage School Information");
					tester.setWorkingForm("info");
					tester.setTextField("schoolname", previousValue);
					tester.clickButtonWithText(" Update ");
					
					tester.clickLinkWithText("Log Out");
			}
		}
}



