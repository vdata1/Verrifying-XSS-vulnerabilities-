import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_244_Page2Att extends FatherClass {

	@Before
	public void prepare(){
		FatherClass("test","test");
	}
	
	@Test
	public void test(){
	
		
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Manage Students");
		
		tester.clickElementByXPath("html//select[@name='report']//option['28']");
		tester.setWorkingForm("students");
		tester.setHiddenField("page2", "28");
		tester.setHiddenField("deletestudent", "0");
		
		addSubmitButton("html//form[@name='students']");
		tester.submit();
		tester.assertMatch("Grade Report");
		
		tester.setWorkingForm("classes");
		
		tester.setHiddenField("page2", "'> <a href=www.unitn.it>malicious link</a> <br '");
		
		addSubmitButton("html//form[@name='classes']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
	
	
}
