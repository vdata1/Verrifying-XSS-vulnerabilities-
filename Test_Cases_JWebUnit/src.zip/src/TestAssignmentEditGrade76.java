import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

public class TestAssignmentEditGrade76 {
	private WebTester tester;
	private String previousValue = null;
	
	@Before	
	public void prepare() {
		tester = new WebTester();
		tester.setBaseUrl("http://192.168.56.102/schoolmate/");
	}
	@Test
	public void test() {
		tester.beginAt("index.php");
		tester.setTextField("username","mariano");
		tester.setTextField("password","mariano");
		tester.submit();
		
		tester.assertMatch("Mariano Ceccato's Classes");
		tester.clickLinkWithText("Security Testing");
		tester.assertMatch("Class Settings");
		tester.clickLinkWithText("Grades");
		tester.assertMatch("Grades");
		tester.clickElementByXPath("html//select[@name='assignment']//option[1]");
		tester.clickElementByXPath("html//input[@name='delete[]']");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Grade");
		tester.setWorkingForm("editgrade");
		previousValue = tester.getElementByXPath("html//input[@name='assignment']").getTextContent();
		tester.setHiddenField("assignment","2'><a href=\"//google\">(xss)</a><br'");
		tester.clickButtonWithText("Edit Grade");
		tester.assertLinkNotPresentWithText("xss");
	}
	
}
