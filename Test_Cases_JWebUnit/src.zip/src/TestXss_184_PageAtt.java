

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_184_PageAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("professor","professor");
		
	}


	@Test
	public void test(){
		tester.clickLinkWithExactText("Steganography");
		tester.assertMatch("Class Settings");
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Students");
		tester.setWorkingForm("classes");
		tester.setHiddenField("page", "'> <a href=www.unitn.it>malicious link</a> <br '");
		addSubmitButton("html//form[@name='classes']");
		tester.submit(); 
		//tester.clickLinkWithExactText("Classes");
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
}

