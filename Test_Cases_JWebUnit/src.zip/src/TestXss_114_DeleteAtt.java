import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

//Transformation Made.
public class TestXss_114_DeleteAtt extends FatherClass{
	
	
	
	@Before
	public void prepare(){
		FatherClass("test","test");
	}
	
	@Test
	public void test(){
		
		tester.clickLinkWithExactText("Teachers");
		tester.assertMatch("Manage Teachers");
		tester.setWorkingForm("teachers");
		tester.checkCheckbox("delete[]","2");
		
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Teacher"); 
		
		tester.setWorkingForm("editteacher");
		tester.setHiddenField("teacherid", "2'> <a href=www.unitn.it>malicious link</a>");
		
		
		tester.clickButtonWithText("Edit teacher");
		//addSubmitButton("html//form[@name='editteacher']");
		//tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");
		
	}
}