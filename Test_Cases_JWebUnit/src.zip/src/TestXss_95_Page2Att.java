import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_95_Page2Att extends FatherClass {
		
		
		@Before	
		public void prepare() {
			FatherClass("test", "test");
		}
		@Test
		public void test() {
			tester.clickLinkWithExactText("School");
			tester.assertMatch("Manage School Information");
			tester.setWorkingForm("info"); 
			tester.setTextField("page2", "1'> <a  href=\"unitn.it\">malicious link</a>");
			addSubmitButton("html//form[@name='info']");
			tester.submit();
			tester.assertLinkNotPresentWithText("malicious link");
		}
	}


