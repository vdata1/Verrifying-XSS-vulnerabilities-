import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_145_StudentAtt extends FatherClass{
	@Before
	public void prepare(){
		FatherClass("parent","parent");
		
	}
	
	@Test
	public void test(){
		
		//tester.setWorkingForm("classes");
		tester.clickLinkWithExactText("AbdulRahman Hamdan");
		tester.assertMatch("AbdulRahman Hamdan's Classes");
		tester.setWorkingForm("classes");
		tester.setHiddenField("student", "1'> <a href=www.unitn.it>malicious link</a> <br '");
		tester.clickLinkWithExactText("Classes");
		//tester.setWorkingForm("classes");

		//addSubmitButton("html//form[@name='classes']");
		//tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");
		
	}
}
