import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_276_OnPageAtt extends FatherClass {

	@Before
	public void prepare(){
		FatherClass("test","test");
	}
	
	@Test
	public void test(){
	
		
		tester.clickLinkWithExactText("Teachers");
		tester.assertMatch("Manage Teachers");
		
		tester.setWorkingForm("teachers");
		
		tester.setHiddenField("onpage", "'> <a href=www.unitn.it>malicious link</a> <br '");
		
		addSubmitButton("html//form[@name='teachers']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
	
	
}
