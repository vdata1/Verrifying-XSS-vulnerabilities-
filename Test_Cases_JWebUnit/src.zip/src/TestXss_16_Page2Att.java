import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_16_Page2Att extends FatherClass{
	@Before 
	public void prepare(){
		FatherClass("test","test");
	}
	@Test
	public void test(){
		tester.clickLinkWithText("Announcements");
		tester.assertMatch("Manage Announcements");		
		tester.setWorkingForm("announcements");
		tester.assertMatch("Manage Announcements");
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New Announcement");
		
		tester.setWorkingForm("addannouncement");
		tester.setTextField("page2","4'> <a href=www.unitn.it>malicious link</a>");
		//tester.clickButtonWithText("Add announcement");
		addSubmitButton("html//form[@name='addannouncement']");
		tester.submit();
		
		tester.assertLinkNotPresentWithText("malicious link");
	}

}
