

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_215_PageAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test","test");
		
	}

	@Test
	public void test(){
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Manage Students");
		tester.clickElementByXPath("html//select[@name='report']//option['32']");
		tester.setWorkingForm("students");
		addSubmitButton("html//form[@name='students']");
		tester.setHiddenField("page2", "32");
		tester.setHiddenField("deletestudent", "0");
		tester.setHiddenField("onpage", "1");
		//tester.setHiddenField("term", "1");
		tester.submit();
		tester.assertMatch("Points Report");
		tester.setWorkingForm("classes");
		tester.setHiddenField("page", "'> <a href=www.unitn.it>malicious link</a> <br '");
		addSubmitButton("html//form[@name='classes']");
		tester.submit(); 
		//tester.clickLinkWithExactText("Classes");
		tester.assertLinkNotPresentWithText("malicious link");
	}
}


