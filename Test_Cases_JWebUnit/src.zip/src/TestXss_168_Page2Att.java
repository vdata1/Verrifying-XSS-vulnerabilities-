

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_168_Page2Att extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("student","student");
		
	}


	@Test
	public void test(){
		tester.clickLinkWithExactText("Classes");
		tester.assertMatch("AbdulRahman Hamdan's Classes");
		tester.setWorkingForm("student");
		
		tester.setHiddenField("page2", "1'> <a href=www.unitn.it>malicious link</a>");
		tester.setWorkingForm("student");
		addSubmitButton("html//form[@name='student']");
		tester.submit(); 
		
		tester.assertLinkNotPresentWithText("malicious link");
		
		
	}
}