import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_93_PageAtt extends FatherClass {
		
		
		@Before	
		public void prepare() {
			FatherClass("parent", "parent");
		}
		@Test
		public void test() {
			
			tester.setWorkingForm("classes"); 
			tester.setTextField("page", "5'> <a  href=\"unitn.it\">malicious link</a>");
			addSubmitButton("html//form[@name='classes']");
			tester.submit();
			//tester.clickLinkWithExactText("AbdulRahman Hamdan");
			tester.assertLinkNotPresentWithText("malicious link");
		}
	}


