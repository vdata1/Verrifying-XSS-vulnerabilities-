import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_91_SelectClassAtt extends FatherClass {
		
		
		@Before	
		public void prepare() {
			FatherClass("student", "student");
		}
		@Test
		public void test() {
			tester.clickLinkWithExactText("Steganography");
			tester.assertMatch("Class Settings");
			tester.setWorkingForm("student"); 
			tester.setTextField("selectclass", "1'> <a  href=\"unitn.it\">malicious link</a>");
			tester.clickLinkWithExactText("Settings"); 
			
			tester.assertLinkNotPresentWithText("malicious link");
		}
	}

