import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_55 extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test", "test");
	}
	
	@Test
	public void test(){ 
		tester.clickLinkWithText("School");
		
		tester.assertMatch("Manage School Information");
		previousValue = "VSchool";//tester.getElementByXPath("html//input[@name='schoolname']").getTextContent();
		//System.out.println("previousValue" + "    XXXXXXXXXXXXXXXXXXXXXXXX"); //Empty, Why ? :\ 
		tester.setWorkingForm("info");		
		tester.setTextField("schoolname", "<a href=\"unitn.it\">malicious link</a>");
		tester.clickButtonWithText(" Update ");
		tester.clickLinkWithExactText("Log Out");
		tester.assertLinkNotPresentWithText("malicious link");
	}
	@After
	public void CleanUp(){
		if  (previousValue!=null){
			FatherClass("test","test");
			tester.clickLinkWithText("School");
			tester.assertMatch("Manage School Information");
			tester.setWorkingForm("info");		
			tester.setTextField("schoolname", previousValue);
			tester.clickButtonWithText(" Update ");
		}
		
	}
}
