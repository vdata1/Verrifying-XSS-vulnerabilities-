import org.junit.*;
import net.sourceforge.jwebunit.junit.*;

import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_42_DeleteAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test", "test");
	}

	@Test
	public void myTest(){
		
		tester.clickLinkWithText("Announcements");
		
		tester.assertMatch("Manage Announcements");
		tester.setWorkingForm("announcements");
		tester.checkCheckbox("delete[]","1");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Announcement");
		tester.setWorkingForm("editannouncement");
		tester.setTextField("announcementid", "1'> <a href=\"unitn.it\">malicious link</a><br '");
		tester.clickButtonWithText("Edit Announcement");		
		tester.assertLinkNotPresentWithText("malicious link");	
	}
}
