

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.xml.sax.helpers.AttributesImpl;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;

public class TestXss_194_PageAtt extends FatherClass{

	@Before
	public void prepare(){
		FatherClass("test","test");
		
	}

	@Test
	public void test(){
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Manage Students");
		//tester.setWorkingForm("");
		//tester.clickElementByXPath("html//select[@name='report']//option['27']");
		tester.setWorkingForm("students");
		addSubmitButton("html//form[@name='students']");
		tester.setHiddenField("page","'> <a href=www.unitn.it>malicious link</a> <br'");
		tester.setHiddenField("page2","27");
		tester.setHiddenField("deletestudent", "0");
		tester.submit();
		tester.assertLinkNotPresentWithText("malicious link");
	}
}


